import WaymarkLogo from './WaymarkLogo';
import { G } from '../constants/theme';
import { PHASES } from '../data/phases';

export default function TopBar({ view, setView, activePhase, setActivePhase, overallPct, phaseProgress }) {
  return (
    <div
      style={{
        position: 'sticky', top: 0, zIndex: 50,
        background: '#0A0A0AF0', backdropFilter: 'blur(12px)',
        borderBottom: `1px solid ${G.border}`,
        padding: '0 28px',
      }}
    >
      {/* Top row */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 0', flexWrap: 'wrap', gap: 12,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <WaymarkLogo size={32} />
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 17, letterSpacing: 2 }}>
              Waymark <span style={{ color: G.gold }}>Consulting</span>
            </div>
            <div style={{ fontSize: 9, color: G.muted, letterSpacing: 3, marginTop: 1 }}>
              LAUNCH PLAYBOOK
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: 4 }}>
            <button
              className={`view-toggle ${view === 'guide' ? 'active' : ''}`}
              onClick={() => setView('guide')}
            >
              GUIDE
            </button>
            <button
              className={`view-toggle ${view === 'overview' ? 'active' : ''}`}
              onClick={() => setView('overview')}
            >
              OVERVIEW
            </button>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 100, height: 2, background: G.dim, borderRadius: 2, overflow: 'hidden' }}>
              <div style={{
                width: `${overallPct}%`, height: '100%',
                background: `linear-gradient(90deg, ${G.goldDark}, ${G.goldBright || '#F0C040'})`,
                transition: 'width 0.5s',
              }} />
            </div>
            <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 15, color: G.gold }}>
              {overallPct}%
            </span>
          </div>
        </div>
      </div>

      {/* Phase nav pills — guide view only */}
      {view === 'guide' && (
        <div style={{
          display: 'flex', gap: 4, paddingBottom: 12,
          overflowX: 'auto', borderTop: `1px solid ${G.border}`, paddingTop: 10,
        }}>
          {PHASES.map((p, i) => {
            const prog = phaseProgress(p);
            return (
              <button
                key={p.id}
                className={`phase-pill ${activePhase === i ? 'active' : ''}`}
                onClick={() => setActivePhase(i)}
              >
                <span style={{ marginRight: 6, opacity: 0.7 }}>{p.icon}</span>
                {p.label}
                {prog.done > 0 && (
                  <span style={{
                    marginLeft: 6, fontSize: 9,
                    color: prog.done === prog.total ? G.gold : G.muted,
                  }}>
                    {prog.done}/{prog.total}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
