import { G } from '../constants/theme';

export default function GoldBar({ pct, color = G.gold, height = 2 }) {
  return (
    <div style={{ width: '100%', height, background: G.dim, borderRadius: height }}>
      <div
        style={{
          width: `${pct}%`,
          height: '100%',
          background: `linear-gradient(90deg, ${G.goldDark}, ${color})`,
          borderRadius: height,
          transition: 'width 0.5s ease',
        }}
      />
    </div>
  );
}
