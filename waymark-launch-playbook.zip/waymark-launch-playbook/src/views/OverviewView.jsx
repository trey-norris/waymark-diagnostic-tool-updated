import GoldBar from '../components/GoldBar';
import { G } from '../constants/theme';
import { PHASES } from '../data/phases';

export default function OverviewView({ setActivePhase, setView, phaseProgress, totalSteps, totalDone, overallPct }) {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '56px 28px' }}>

      {/* Intro */}
      <div style={{ marginBottom: 52 }}>
        <div style={{ fontSize: 9, color: G.muted, letterSpacing: 4, marginBottom: 14 }}>
          YOUR ROADMAP
        </div>
        <h1 style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontSize: 'clamp(36px, 5vw, 52px)',
          lineHeight: 1.1, marginBottom: 16,
        }}>
          Launch in<br /><span style={{ color: G.gold }}>5 Phases</span>
        </h1>
        <p style={{ color: G.muted, fontSize: 13, lineHeight: 1.9, maxWidth: 480 }}>
          A complete launch system for Waymark Consulting — from legal formation to your first clients and beyond.
        </p>
      </div>

      {/* Phase cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {PHASES.map((p, i) => {
          const prog = phaseProgress(p);
          return (
            <div
              key={p.id}
              onClick={() => { setActivePhase(i); setView('guide'); }}
              style={{
                background: G.surface,
                border: `1px solid ${prog.done > 0 ? G.borderGold : G.border}`,
                borderRadius: 12, padding: '28px 32px', cursor: 'pointer',
                display: 'flex', gap: 28, alignItems: 'center', flexWrap: 'wrap',
                transition: 'border-color 0.2s',
              }}
            >
              <div style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: 56, color: '#1E1E1E', lineHeight: 1, minWidth: 56,
              }}>
                {p.phase}
              </div>

              <div style={{ flex: 1, minWidth: 200 }}>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 6, flexWrap: 'wrap' }}>
                  <span style={{ color: p.color, fontSize: 14 }}>{p.icon}</span>
                  <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22 }}>{p.label}</span>
                  <span style={{ fontSize: 10, color: G.muted, letterSpacing: 1 }}>{p.subtitle}</span>
                </div>
                <p style={{ color: G.muted, fontSize: 12, marginBottom: 16, lineHeight: 1.6 }}>{p.tagline}</p>
                <GoldBar pct={prog.pct} color={p.color} height={2} />
              </div>

              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, color: p.color, lineHeight: 1 }}>
                  {prog.done}<span style={{ color: G.dim, fontSize: 16 }}>/{prog.total}</span>
                </div>
                <div style={{ fontSize: 9, color: G.muted, letterSpacing: 2, marginTop: 4 }}>STEPS DONE</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stats */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
        gap: 10, marginTop: 28,
      }}>
        {[
          { label: 'Total Steps', value: totalSteps },
          { label: 'Completed',   value: totalDone },
          { label: 'Remaining',   value: totalSteps - totalDone },
          { label: 'Progress',    value: `${overallPct}%` },
        ].map(s => (
          <div key={s.label} style={{
            background: G.surface, border: `1px solid ${G.border}`,
            borderRadius: 10, padding: '22px 18px', textAlign: 'center',
          }}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 34, color: G.gold, lineHeight: 1 }}>
              {s.value}
            </div>
            <div style={{ fontSize: 9, color: G.muted, letterSpacing: 2, marginTop: 8 }}>
              {s.label.toUpperCase()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
