export default function WaymarkLogo({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" aria-label="Waymark Logo">
      <defs>
        <linearGradient id="wgLL" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stopColor="#F0C040" />
          <stop offset="50%"  stopColor="#C9A84C" />
          <stop offset="100%" stopColor="#8B6914" />
        </linearGradient>
      </defs>
      <path
        d="M10 20 L28 75 L50 40 L72 75 L90 20"
        stroke="url(#wgLL)" strokeWidth="8"
        strokeLinecap="round" strokeLinejoin="round" fill="none"
      />
      <path d="M50 38 L50 12" stroke="url(#wgLL)" strokeWidth="5" strokeLinecap="round" />
      <path
        d="M42 22 L50 12 L58 22"
        stroke="url(#wgLL)" strokeWidth="5"
        strokeLinecap="round" strokeLinejoin="round" fill="none"
      />
    </svg>
  );
}
