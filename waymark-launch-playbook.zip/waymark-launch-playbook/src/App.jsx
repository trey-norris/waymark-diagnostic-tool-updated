import { useState } from 'react';
import TopBar from './components/TopBar';
import GuideView from './views/GuideView';
import OverviewView from './views/OverviewView';
import { PHASES } from './data/phases';

export default function App() {
  const [view, setView] = useState('guide');
  const [activePhase, setActivePhase] = useState(0);
  const [checked, setChecked] = useState({});

  const toggle = (id) => setChecked(prev => ({ ...prev, [id]: !prev[id] }));

  const phaseProgress = (phase) => {
    const done = phase.steps.filter(s => checked[s.id]).length;
    return {
      done,
      total: phase.steps.length,
      pct: Math.round((done / phase.steps.length) * 100),
    };
  };

  const totalSteps = PHASES.reduce((a, p) => a + p.steps.length, 0);
  const totalDone  = Object.values(checked).filter(Boolean).length;
  const overallPct = Math.round((totalDone / totalSteps) * 100);

  return (
    <div style={{ minHeight: '100vh', background: '#0A0A0A' }}>
      <TopBar
        view={view}
        setView={setView}
        activePhase={activePhase}
        setActivePhase={setActivePhase}
        overallPct={overallPct}
        phaseProgress={phaseProgress}
      />

      {view === 'guide' && (
        <GuideView
          activePhase={activePhase}
          setActivePhase={setActivePhase}
          checked={checked}
          onToggle={toggle}
          phaseProgress={phaseProgress}
        />
      )}

      {view === 'overview' && (
        <OverviewView
          setActivePhase={setActivePhase}
          setView={setView}
          phaseProgress={phaseProgress}
          totalSteps={totalSteps}
          totalDone={totalDone}
          overallPct={overallPct}
        />
      )}
    </div>
  );
}
