export const PHASES = [
  {
    id: "foundation",
    phase: "01",
    label: "Foundation",
    subtitle: "Weeks 1–2",
    icon: "◈",
    color: "#C9A84C",
    tagline: "Build the base everything else stands on.",
    steps: [
      {
        id: "f1",
        title: "Register Your Business Entity",
        priority: "CRITICAL",
        time: "1–2 days",
        cost: "$100–200",
        detail:
          "Form an LLC in your state. Oklahoma filing is ~$104. Use LegalZoom or your state's SOS website directly. Protects personal assets and establishes legitimacy with every client you approach.",
        tools: ["Oklahoma SOS (sos.ok.gov)", "LegalZoom", "Northwest Registered Agent"],
      },
      {
        id: "f2",
        title: "Open a Business Bank Account",
        priority: "CRITICAL",
        time: "1 day",
        cost: "$0–25/mo",
        detail:
          "Never mix personal and business funds. Chase Business Checking or Relay (no fees, built for small business) are both solid. You'll need your EIN and LLC docs to open.",
        tools: ["Chase Business Checking", "Relay Bank (free)", "Mercury Bank"],
      },
      {
        id: "f3",
        title: "Get Your EIN from the IRS",
        priority: "CRITICAL",
        time: "15 minutes",
        cost: "Free",
        detail:
          "Free and instant at IRS.gov/EIN. You need this for your bank account, contracts, and taxes. Takes under 10 minutes — do this before anything else.",
        tools: ["IRS.gov/EIN (free)"],
      },
      {
        id: "f4",
        title: "Set Up Basic Bookkeeping",
        priority: "HIGH",
        time: "1–2 days",
        cost: "$0–18/mo",
        detail:
          "Start with Wave (free) or QuickBooks Simple Start. Connect your business bank account immediately. Track every dollar from day one — you'll thank yourself at tax time and when clients ask about ROI.",
        tools: ["Wave (free)", "QuickBooks Simple Start", "FreshBooks"],
      },
      {
        id: "f5",
        title: "Create Your Master Service Agreement",
        priority: "HIGH",
        time: "2–3 days",
        cost: "$0–300",
        detail:
          "A 1–2 page contract covering scope of work, payment terms, IP ownership, confidentiality, and termination. Use Bonsai templates, then have an attorney review once. This protects you on every engagement.",
        tools: ["Bonsai (templates)", "HelloSign", "DocuSign"],
      },
      {
        id: "f6",
        title: "Define Your Service Packages & Pricing",
        priority: "HIGH",
        time: "2–3 days",
        cost: "Free",
        detail:
          "Build 3 tiers: Starter (~$1,500), Growth (~$3,500), Scale ($6,000+). Each needs clear deliverables, a defined timeline, and measurable outcomes. Anchor pricing on value delivered — not hours worked.",
        tools: ["Claude AI", "Notion", "Google Docs"],
      },
    ],
  },
  {
    id: "presence",
    phase: "02",
    label: "Market Presence",
    subtitle: "Weeks 2–4",
    icon: "◉",
    color: "#D4A84C",
    tagline: "Look the part. Be found. Build trust before the first call.",
    steps: [
      {
        id: "p1",
        title: "Secure Your Domain & Professional Email",
        priority: "CRITICAL",
        time: "1 day",
        cost: "$12/yr + $6/mo",
        detail:
          "Get waymarkconsulting.com (or .co). Set up Google Workspace for a @waymarkconsulting.com email address. Never use a Gmail account for client work — it signals you're not a serious operation.",
        tools: ["Namecheap", "Google Workspace", "Cloudflare"],
      },
      {
        id: "p2",
        title: "Build Your Website",
        priority: "HIGH",
        time: "3–5 days",
        cost: "$15–25/mo",
        detail:
          "You don't need custom code. Use Webflow or Squarespace. Five pages: Home, Services, About, Case Studies (add later), Contact. One headline: who you help and exactly what you do for them.",
        tools: ["Webflow ($16/mo)", "Squarespace ($16/mo)", "Framer ($15/mo)"],
      },
      {
        id: "p3",
        title: "Optimize Your LinkedIn Profile",
        priority: "HIGH",
        time: "1 day",
        cost: "Free",
        detail:
          "Rewrite your headline: 'I help small service businesses in rural America build systems, implement AI, and scale.' Lead with outcomes. Add your MBA, OKC experience, and a clear CTA. Post once per week minimum.",
        tools: ["LinkedIn", "Canva (graphics)", "Shield Analytics"],
      },
      {
        id: "p4",
        title: "Set Up Google Business Profile",
        priority: "MEDIUM",
        time: "1 day",
        cost: "Free",
        detail:
          "Even as a consultant, a Google Business Profile makes you findable and adds immediate credibility. Aim for your first 5 reviews from colleagues or early clients within the first 30 days.",
        tools: ["Google Business Profile (free)"],
      },
      {
        id: "p5",
        title: "Create a Client-Facing Pitch Deck",
        priority: "HIGH",
        time: "2 days",
        cost: "Free–$12/mo",
        detail:
          "8–10 slides: the problem you solve, your approach, service packages, why Waymark, and a simple next step. This is your leave-behind after every intro call. Keep it visual — minimal text per slide.",
        tools: ["Claude AI", "Canva", "Beautiful.ai"],
      },
    ],
  },
  {
    id: "clients",
    phase: "03",
    label: "First Clients",
    subtitle: "Weeks 3–6",
    icon: "◎",
    color: "#BF9840",
    tagline: "Your first 3 clients are everything. Go get them deliberately.",
    steps: [
      {
        id: "c1",
        title: "Build Your Target 50 List",
        priority: "CRITICAL",
        time: "2–3 days",
        cost: "$0–49/mo",
        detail:
          "List 50 small businesses in your target market you could realistically help. Use Google Maps, LinkedIn, and local chambers of commerce. Include owner name, business type, phone, and email for each.",
        tools: ["Google Maps", "LinkedIn", "Hunter.io", "Apollo.io"],
      },
      {
        id: "c2",
        title: "Craft Your Outreach Message",
        priority: "CRITICAL",
        time: "1 day",
        cost: "Free",
        detail:
          "3-sentence formula: (1) A specific observation about their business. (2) The exact problem you solve. (3) A low-friction ask. Never lead with your services or credentials. Ask Claude to write 5 versions and test them.",
        tools: ["Claude AI", "GMass", "Instantly.ai"],
      },
      {
        id: "c3",
        title: "Offer a Free Diagnostic Session",
        priority: "HIGH",
        time: "Ongoing",
        cost: "Free",
        detail:
          "Use the Waymark Diagnostic Tool to run a free 45-minute session. Deliver immediate, tangible value. At the end, present the results and your recommended engagement. Close rate on warm diagnostics is very high.",
        tools: ["Waymark Diagnostic Tool", "Calendly", "Zoom"],
      },
      {
        id: "c4",
        title: "Join 3 Local Business Organizations",
        priority: "HIGH",
        time: "1 week",
        cost: "$200–600/yr",
        detail:
          "Oklahoma Chamber, a local BNI chapter, and the SCORE mentor network. Show up consistently. Referrals from trusted networks close faster and at higher rates than any cold outreach campaign.",
        tools: ["Oklahoma Chamber", "BNI.com", "SCORE.org"],
      },
      {
        id: "c5",
        title: "Close Your First Paid Engagement",
        priority: "CRITICAL",
        time: "Weeks 3–6",
        cost: "2.9% processing",
        detail:
          "Target a $1,500–3,500 starter engagement. Don't discount your rate — offer a smaller pilot scope instead. Get a signed contract and 50% deposit upfront before any work begins. Deliver extraordinary results and document everything.",
        tools: ["Bonsai", "Stripe", "QuickBooks"],
      },
    ],
  },
  {
    id: "systems",
    phase: "04",
    label: "Operating Systems",
    subtitle: "Weeks 4–8",
    icon: "⟳",
    color: "#C9A84C",
    tagline: "Build the machine that runs your consulting business.",
    steps: [
      {
        id: "s1",
        title: "Set Up Your CRM",
        priority: "HIGH",
        time: "2 days",
        cost: "Free–$14/mo",
        detail:
          "Start with HubSpot Free. Create pipelines: Prospect → Diagnostic Scheduled → Proposal Sent → Active Client → Retention. Log every single interaction. This is your business's memory and your pipeline at a glance.",
        tools: ["HubSpot Free", "Pipedrive ($14/mo)", "Notion CRM template"],
      },
      {
        id: "s2",
        title: "Build Your Project Delivery System",
        priority: "HIGH",
        time: "2–3 days",
        cost: "$0–8/mo",
        detail:
          "Use Notion or ClickUp. Create a master client template with: kickoff checklist, weekly update structure, deliverable tracker, and offboarding checklist. Clone it for every new client — never start from scratch.",
        tools: ["Notion ($8/mo)", "ClickUp (free)", "Asana"],
      },
      {
        id: "s3",
        title: "Automate Scheduling & Client Intake",
        priority: "MEDIUM",
        time: "1 day",
        cost: "$0–10/mo",
        detail:
          "Calendly for booking. Build a pre-call intake form asking: business type, revenue range, biggest challenge, top 3 goals. Review responses 15 minutes before every call so you walk in prepared and focused.",
        tools: ["Calendly ($10/mo)", "Typeform", "Google Forms (free)"],
      },
      {
        id: "s4",
        title: "Create Your Client Reporting Template",
        priority: "HIGH",
        time: "2 days",
        cost: "Free",
        detail:
          "Build a weekly update template: work completed, metrics moved, blockers, next steps. Clients who feel consistently informed refer more and churn less. Use Claude to generate these updates from your raw notes.",
        tools: ["Claude AI", "Notion", "Google Slides"],
      },
      {
        id: "s5",
        title: "Set Up Invoicing & Payment Flow",
        priority: "CRITICAL",
        time: "1 day",
        cost: "$19/mo + fees",
        detail:
          "Bonsai or QuickBooks for invoicing. Stripe for payments. Always collect 50% upfront, 50% on completion — or bill monthly on retainer. Include a late payment clause in your contract and auto-reminders on overdue invoices.",
        tools: ["Bonsai ($19/mo)", "Stripe", "QuickBooks"],
      },
    ],
  },
  {
    id: "scale",
    phase: "05",
    label: "Scale & Growth",
    subtitle: "Months 2–6",
    icon: "◆",
    color: "#E8C870",
    tagline: "From freelancer to firm. Build leverage, not just more hours.",
    steps: [
      {
        id: "sc1",
        title: "Build Your Case Study Library",
        priority: "HIGH",
        time: "Ongoing",
        cost: "Free",
        detail:
          "After every engagement, document: the situation before, your intervention, and the measurable outcome. One strong case study ('helped an HVAC company reduce no-shows by 40%') closes more deals than any pitch deck.",
        tools: ["Claude AI", "Notion", "Your website"],
      },
      {
        id: "sc2",
        title: "Launch a Monthly Newsletter",
        priority: "MEDIUM",
        time: "1 week setup",
        cost: "Free–$25/mo",
        detail:
          "One email per month to your network: one insight, one tool recommendation, one client win (anonymized). Beehiiv is free up to 2,500 subscribers. Consistency matters far more than frequency.",
        tools: ["Beehiiv (free)", "ConvertKit", "Substack"],
      },
      {
        id: "sc3",
        title: "Launch a Referral Program",
        priority: "HIGH",
        time: "1 day",
        cost: "Commission only",
        detail:
          "Offer existing clients and professional contacts 10–15% of any referred engagement that closes. Put it in writing, tell everyone in your network, and follow up quarterly. Your best leads come from people who've seen your work.",
        tools: ["Claude AI (write the referral email)", "Bonsai"],
      },
      {
        id: "sc4",
        title: "Build Your AI Delivery Toolkit",
        priority: "HIGH",
        time: "Ongoing",
        cost: "$20–50/mo",
        detail:
          "Use Claude for drafting SOPs, writing job descriptions, building meeting agendas, analyzing financials, and writing marketing copy for clients. Build a prompt library of your 20 most-used workflows. This multiplies your capacity without adding hours.",
        tools: ["Claude AI Pro ($20/mo)", "Make.com", "Zapier"],
      },
      {
        id: "sc5",
        title: "Plan Your First Hire or Contractor",
        priority: "MEDIUM",
        time: "Month 4–6",
        cost: "$15–35/hr",
        detail:
          "When you're consistently at 80%+ capacity, it's time to bring someone in. Your first addition is typically a part-time operations coordinator or a subcontract consultant. Document everything before you hire — solid systems make onboarding fast.",
        tools: ["Indeed", "LinkedIn Jobs", "Upwork (contractors)"],
      },
    ],
  },
];

export const PRIORITY_COLOR = {
  CRITICAL: "#EF4444",
  HIGH: "#F97316",
  MEDIUM: "#C9A84C",
};
