import { G, } from '../constants/theme';
import { PRIORITY_COLOR } from '../data/phases';

export default function StepCard({ step, index, done, onToggle, phaseColor }) {
  return (
    <div
      style={{
        background: done ? '#0F0F0F' : G.surface,
        border: `1px solid ${done ? G.borderGold : G.border}`,
        borderRadius: 14,
        overflow: 'hidden',
        transition: 'border-color 0.25s, background 0.25s',
      }}
    >
      {/* Top accent line */}
      <div
        style={{
          height: 2,
          background: done
            ? `linear-gradient(90deg, ${G.goldDark}, ${phaseColor})`
            : 'transparent',
          transition: 'background 0.3s',
        }}
      />

      <div style={{ padding: '32px 36px' }}>
        {/* Meta row */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          marginBottom: 18, flexWrap: 'wrap',
        }}>
          <span style={{
            background: `${PRIORITY_COLOR[step.priority]}15`,
            color: PRIORITY_COLOR[step.priority],
            fontSize: 9, letterSpacing: 2, padding: '3px 10px', borderRadius: 3,
          }}>
            {step.priority}
          </span>
          <span style={{ color: G.dim, fontSize: 11 }}>·</span>
          <span style={{ color: G.muted, fontSize: 11, letterSpacing: 0.5 }}>⏱ {step.time}</span>
          <span style={{ color: G.dim, fontSize: 11 }}>·</span>
          <span style={{ color: G.muted, fontSize: 11, letterSpacing: 0.5 }}>💰 {step.cost}</span>
        </div>

        {/* Title + checkbox */}
        <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start', marginBottom: 24 }}>
          <button
            className={`check-ring ${done ? 'done' : ''}`}
            onClick={onToggle}
            style={{ marginTop: 4 }}
            aria-label={done ? 'Mark incomplete' : 'Mark complete'}
          >
            {done && <span style={{ color: G.gold, fontSize: 13 }}>✓</span>}
          </button>

          <h3 style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 'clamp(20px, 3vw, 26px)',
            lineHeight: 1.2,
            color: done ? G.muted : G.text,
            textDecoration: done ? 'line-through' : 'none',
            textDecorationColor: G.dim,
            transition: 'color 0.25s',
            flex: 1,
          }}>
            {step.title}
          </h3>

          <div style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 13, color: G.dim, flexShrink: 0, paddingTop: 6,
          }}>
            {String(index + 1).padStart(2, '0')}
          </div>
        </div>

        {/* Detail */}
        <p style={{
          color: done ? '#555' : '#AAA',
          fontSize: 14, lineHeight: 1.85,
          paddingLeft: 46, marginBottom: 28,
          transition: 'color 0.25s',
        }}>
          {step.detail}
        </p>

        {/* Tools */}
        <div style={{ paddingLeft: 46 }}>
          <div style={{ fontSize: 9, color: G.dim, letterSpacing: 3, marginBottom: 12 }}>
            TOOLS & RESOURCES
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {step.tools.map(t => (
              <span key={t} className="tool-chip">{t}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
