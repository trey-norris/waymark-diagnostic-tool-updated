export const G = {
  gold:       "#C9A84C",
  goldBright: "#F0C040",
  goldDark:   "#8B6914",
  black:      "#0A0A0A",
  surface:    "#111111",
  surface2:   "#181818",
  border:     "#2A2A2A",
  borderGold: "#C9A84C33",
  text:       "#F5F5F0",
  muted:      "#777770",
  dim:        "#3A3A3A",
};
