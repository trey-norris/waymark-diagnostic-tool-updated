import GoldBar from '../components/GoldBar';
import StepCard from '../components/StepCard';
import { G } from '../constants/theme';
import { PHASES } from '../data/phases';

export default function GuideView({ activePhase, setActivePhase, checked, onToggle, phaseProgress }) {
  const phase = PHASES[activePhase];
  const prog = phaseProgress(phase);

  return (
    <div style={{ maxWidth: 780, margin: '0 auto', padding: '52px 28px 80px' }}>

      {/* Phase header */}
      <div style={{ marginBottom: 52 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
          <div style={{
            width: 2, height: 48,
            background: `linear-gradient(180deg, ${phase.color}, transparent)`,
            borderRadius: 1,
          }} />
          <div>
            <div style={{ fontSize: 9, color: G.muted, letterSpacing: 4, marginBottom: 6 }}>
              PHASE {phase.phase} OF 05 · {phase.subtitle}
            </div>
            <h2 style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: 'clamp(30px, 4vw, 42px)',
              lineHeight: 1, color: G.text,
            }}>
              {phase.label}
            </h2>
          </div>
        </div>

        <p style={{
          color: G.muted, fontSize: 13, fontStyle: 'italic',
          lineHeight: 1.7, marginBottom: 20, paddingLeft: 14,
        }}>
          {phase.tagline}
        </p>

        <div style={{ display: 'flex', alignItems: 'center', gap: 14, paddingLeft: 14 }}>
          <GoldBar pct={prog.pct} color={phase.color} height={2} />
          <span style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 16, color: phase.color, flexShrink: 0,
          }}>
            {prog.done} / {prog.total}
          </span>
        </div>
      </div>

      {/* Step cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        {phase.steps.map((step, si) => (
          <StepCard
            key={step.id}
            step={step}
            index={si}
            done={!!checked[step.id]}
            onToggle={() => onToggle(step.id)}
            phaseColor={phase.color}
          />
        ))}
      </div>

      {/* Phase nav */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        marginTop: 60, paddingTop: 32, borderTop: `1px solid ${G.border}`,
      }}>
        {activePhase > 0 ? (
          <button className="nav-btn" onClick={() => setActivePhase(p => p - 1)}>
            ← {PHASES[activePhase - 1].label}
          </button>
        ) : <div />}

        {activePhase < PHASES.length - 1 ? (
          <button className="gold-btn" onClick={() => setActivePhase(p => p + 1)}>
            {PHASES[activePhase + 1].label} →
          </button>
        ) : (
          <div style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 16, color: G.gold, fontStyle: 'italic',
          }}>
            Playbook complete. ◆
          </div>
        )}
      </div>
    </div>
  );
}
